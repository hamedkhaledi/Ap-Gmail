package Model;

public enum Gender {
  Male , Female;
}
