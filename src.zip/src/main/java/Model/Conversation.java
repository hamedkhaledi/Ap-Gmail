package Model;

import java.util.LinkedList;

public class Conversation {
  private LinkedList<Message> messages;
}
