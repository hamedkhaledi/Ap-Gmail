package Controller;

import static Model.Main.ME;

import Model.ALL_MESSAGES;
import Model.IO.FxmlLoader;
import Model.Message;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Paths;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class MessageListItemController {

  private Message message;

  @FXML
  private AnchorPane root;
  @FXML
  private Label textLabel;
  @FXML
  private Label subjectLabel;
  @FXML
  private Label timeLabel;
  @FXML
  private Button starButton;
  @FXML
  private ImageView imageView;

  public MessageListItemController(Message message) throws IOException {
    this.message = message;
    new FxmlLoader().load("./src/main/java/View/MessageListItem.fxml", this);
  }

  public AnchorPane init() {
    subjectLabel.setText(message.getSubject());
    textLabel.setText(message.getText());
    timeLabel.setText(message.getTime());
    if (message.isImportant()) {
      starButton.setStyle("-icon-paint: gold;\n"
          + "-fx-background-color: -icon-paint;\n"
          + "-fx-border-style: solid;\n"
          + "-fx-min-height: 20;\n"
          + "-fx-max-height: 20;\n"
          + "-fx-min-width: 20;\n"
          + "-fx-max-width: 20;\n"
          + "-fx-shape:  \"M 0.000 5.000L 5.878 8.090L 4.755 1.545L 9.511 -3.090L 2.939 -4.045L 0.000 -10.000L -2.939 -4.045L -9.511 -3.090L -4.755 1.545L -5.878 8.090L 0.000 5.000\";\n");
    }
    if(message.getReciever().getUsername().equals(ME.getUsername()) && message.getSender().getUsername().equals(ME.getUsername())){
      imageView.setImage(new Image(Paths.get("./src/main/resources/Icons/saveMail3.png").toUri().toString()));
    }
    else if(message.getReciever().getUsername().equals(ME.getUsername())){
      imageView.setImage(new Image(Paths.get("./src/main/resources/Icons/incoming-mail.png").toUri().toString()));
    }else{
      imageView.setImage(new Image(Paths.get("./src/main/resources/Icons/outgoing.png").toUri().toString()));
    }
    return root;
  }

  public void importantChanger(ActionEvent event) {
    if (message.isImportant()) {
      starButton.setStyle("-icon-paint: white;\n"
          + "-fx-background-color: -icon-paint;\n"
          + "-fx-border-style: solid;\n"
          + "-fx-min-height: 20;\n"
          + "-fx-max-height: 20;\n"
          + "-fx-min-width: 20;\n"
          + "-fx-max-width: 20;\n"
          + "-fx-shape:  \"M 0.000 5.000L 5.878 8.090L 4.755 1.545L 9.511 -3.090L 2.939 -4.045L 0.000 -10.000L -2.939 -4.045L -9.511 -3.090L -4.755 1.545L -5.878 8.090L 0.000 5.000\";\n");
      message.setImportant(false);
    } else {
      starButton.setStyle("-icon-paint: gold;\n"
          + "-fx-background-color: -icon-paint;\n"
          + "-fx-border-style: solid;\n"
          + "-fx-min-height: 20;\n"
          + "-fx-max-height: 20;\n"
          + "-fx-min-width: 20;\n"
          + "-fx-max-width: 20;\n"
          + "-fx-shape:  \"M 0.000 5.000L 5.878 8.090L 4.755 1.545L 9.511 -3.090L 2.939 -4.045L 0.000 -10.000L -2.939 -4.045L -9.511 -3.090L -4.755 1.545L -5.878 8.090L 0.000 5.000\";\n");
      message.setImportant(true);
    }
    try {
      FileOutputStream fileOut =
          new FileOutputStream("./src/main/resources/messages.ser");
      ObjectOutputStream out = new ObjectOutputStream(fileOut);
      out.writeObject(ALL_MESSAGES.getAllMessages());
      out.close();
      fileOut.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
