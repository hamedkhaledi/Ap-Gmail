package Controller;

import Model.ALL_MESSAGES;
import Model.ALL_USERS;
import Model.IO.FxmlLoader;
import Model.Message;
import Model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.*;
import java.io.*;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static Model.ALL_USERS.ClientTemp;
import static Model.Main.ME;

public class SendMailPageController {
    public AnchorPane Pane;
    @FXML
    private TextField To;
    @FXML
    private TextField Text;
    @FXML
    private TextField Subject;
    private String AttachURL;

    public void Attach(MouseEvent mouseEvent) throws IOException {
        FileChooser fileChooser = new FileChooser();
        Stage stage = (Stage) Pane.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null)
            AttachURL = selectedFile.getCanonicalPath();
        else
            AttachURL = "";
        Desktop desktop = Desktop.getDesktop();
        desktop.open(Paths.get(AttachURL).toFile());
        System.out.println(AttachURL);
    }

    public void Send(MouseEvent mouseEvent) throws IOException {
        FileOutputStream fileOut =
                new FileOutputStream("./src/main/resources/messages.ser");
        ObjectOutputStream out = new ObjectOutputStream(fileOut);

        Message message;
        if (ALL_USERS.getAllUsers().contains(new User(To.getText()))) {
            User Temp = ALL_USERS.getAllUsers().get(ALL_USERS.getAllUsers().indexOf(new User(To.getText())));
            if (AttachURL.isEmpty()) {
                message = new Message(ClientTemp, Temp, getCurrentTimeUsingCalendar(), Subject.getText(), Text.getText());
            } else {
                message = new Message(ClientTemp, Temp, getCurrentTimeUsingCalendar(), Subject.getText(), Text.getText(), AttachURL);
            }
            ALL_MESSAGES.getAllMessages().add(message);
            out.writeObject(ALL_MESSAGES.getAllMessages());
            out.close();
            fileOut.close();
            new FxmlLoader().load("./src/main/java/View/EmailPage.fxml");
        } else {
        }
    }

    public void quit(MouseEvent mouseEvent) throws IOException {
        new FxmlLoader().load("./src/main/java/View/EmailPage.fxml");
    }


    public static String getCurrentTimeUsingCalendar() {
        Calendar cal = Calendar.getInstance();
        Date date = cal.getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd/HH:mm");
        return dateFormat.format(date);
    }
}

