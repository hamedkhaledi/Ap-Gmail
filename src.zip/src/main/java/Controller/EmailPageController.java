package Controller;

import Model.ALL_MESSAGES;
import Model.IO.FxmlLoader;
import Model.Message;
import Model.MessageListItem;
import com.sun.javafx.charts.Legend;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

import static Model.ALL_USERS.ClientTemp;
import static Model.Main.ME;

public class EmailPageController {
    @FXML
    public ListView<Message> messagesListView;

    public void Inbox(MouseEvent mouseEvent) {

        ArrayList<Message> messagesToShow = (ArrayList<Message>) ALL_MESSAGES.getAllMessages().stream()
                .filter(a -> a.getReciever().equals(ClientTemp)).collect(
                        Collectors.toList());
        messagesListView.setItems(FXCollections.observableArrayList(messagesToShow));
        messagesListView.setCellFactory(messagesListView -> new MessageListItem());
    }

    public void Compose(MouseEvent mouseEvent) throws IOException {
        new FxmlLoader().load("./src/main/java/View/SendMailPage.fxml");
    }

    public void showImportant(MouseEvent mouseEvent) {
        ArrayList<Message> importantMessages = (ArrayList<Message>) ALL_MESSAGES.getAllMessages()
                .stream()
                .filter(a -> a.getReciever().equals(ClientTemp) && a.isImportant())
                .collect(Collectors.toList());
        messagesListView.setItems(FXCollections.observableArrayList(importantMessages));
        messagesListView.setCellFactory(messagesListView -> new MessageListItem());

    }

    public void showSent(MouseEvent event) {
        ArrayList<Message> sentMessages = (ArrayList<Message>) ALL_MESSAGES.getAllMessages().stream()
                .filter(a -> a.getSender().equals(ClientTemp)).collect(
                        Collectors.toList());
        messagesListView.setItems(FXCollections.observableArrayList(sentMessages));
        messagesListView.setCellFactory(messagesListView -> new MessageListItem());
    }

    public void Exit(MouseEvent mouseEvent) throws IOException {
        new FxmlLoader().load("./src/main/java/View/SignInPage.fxml");
    }
}
